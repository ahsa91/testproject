"use strict";

const express = require("express");
const router = express.Router();
const assessments = require('./controllers/assessments.js');

const accounts = require("./controllers/accounts.js");
const dashboard = require("./controllers/dashboard.js");
const about = require("./controllers/about.js");

router.get('/', accounts.index);
router.get('/login', accounts.login);
router.get('/signup', accounts.signup);
router.get('/logout', accounts.logout);
router.post('/register', accounts.register);
router.post('/authenticate', accounts.authenticate);

router.get("/", dashboard.index);
router.get("/dashboard", dashboard.index);
router.get("/about", about.index);
router.get("/trainerdashboard",dashboard.indexTrainer);

// router.get('/member/:id', dashboard.trainerAssessments);
// router.get('/deletemember/:id', accounts.deleteMember);
router.get('/deleteassessment/:memberid/:id', assessments.deleteAssessment);
router.post('/dashboard/addassessment', assessments.addAssessment);
//
//
router.post('/editcomment/:id', assessments.editComment);

module.exports = router;
