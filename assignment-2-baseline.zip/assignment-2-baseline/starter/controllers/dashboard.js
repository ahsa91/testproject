"use strict";

const logger = require("../utils/logger");
const memberStore = require('../models/member-store');
const accounts = require ('./accounts');


const dashboard = {
  index(request, response) {
    logger.info("dashboard rendering");
    const viewData = {
      title: "Template 1 Dashboard",
    };
    response.render("dashboard", viewData);
  },

  indexTrainer(request,response){
    logger.info("trainerdashboard rendering");
    const viewData = {
      title:"Trainer Dashboard",
      members:memberStore.getAllMembers(),
    };
    response.render("trainerdashboard",viewData);
  }
};

module.exports = dashboard;
